// Simple to-do functionality
document.addEventListener('DOMContentLoaded', function(){
  const addBtn = document.getElementById('addBtn');
  const newTask = document.getElementById('newTask');
  const list = document.getElementById('list');

  function addTask(text){
    if(!text) return;
    const li = document.createElement('li');
    li.textContent = text;
    const btn = document.createElement('button');
    btn.textContent = 'Remove';
    btn.className = 'remove';
    btn.onclick = () => li.remove();
    li.appendChild(btn);
    list.appendChild(li);
    newTask.value = '';
  }

  addBtn.addEventListener('click', ()=> addTask(newTask.value.trim()));
  newTask.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') addTask(newTask.value.trim()) });
});
