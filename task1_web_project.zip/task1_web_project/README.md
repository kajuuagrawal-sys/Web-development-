# Task-1: Web Development (Sample Project)

This is a simple web project created for "Task-1" submission. It contains:
- `index.html` — main page
- `styles.css` — styling
- `script.js` — small JS to demonstrate interactivity

## How to run locally
1. Clone or download the repository.
2. Open `index.html` in a browser.

## Make your changes
- Replace "Your Name" in the contact section.
- Update the GitHub repo link in the page (or keep it as-is).

---
Prepared for submission.
